
  # Homepage mockup for Proyecto X

  This is a code bundle for Homepage mockup for Proyecto X. The original project is available at https://www.figma.com/design/swyeyr5K13lE63dr8TjlJO/Homepage-mockup-for-Proyecto-X.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  